const baseUrl = process.env.VUE_APP_BASE_API
const api = {
  state: {
    baseApi: baseUrl
  }
}

export default api
