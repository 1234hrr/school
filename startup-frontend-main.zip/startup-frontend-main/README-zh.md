# 前端项目

# 安装依赖
npm install

# 运行
npm run dev

# 登录
管理员账号： admin@163.com

管理员密码： 121212qw
```


